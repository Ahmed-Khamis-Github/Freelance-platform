<?php 
return [
    'roles.view'=> 'can view roles' ,
    'roles.create'=> 'can create roles' ,
    'roles.update'=>'can update roles' ,
    'roles.delete'=> 'can delete roles' ,


    'categories.view'=> 'can view categories' ,
    'categories.create'=> 'can create categories' ,
    'categories.update'=>'can update categories' ,
    'categories.delete'=> 'can delete categories' ,


    'users.view'=> 'can view users' ,
    'users.create'=> 'can create users' ,
    'users.update'=>'can update users' ,
    'users.delete'=> 'can delete users'

] ;