<!-- Dashboard Headline -->
<div class="dashboard-headline">
    <h3>Post a Job</h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Breadcrumbs -->
    <nav id="breadcrumbs" class="dark">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Dashboard</a></li>
            <li>Post a Job</li>
        </ul>
    </nav>
</div>

<!-- Row -->

<div class="row">

    <!-- Dashboard Box -->
    <div class="col-xl-12">
        <div class="dashboard-box margin-top-0">

            <!-- Headline -->
            <div class="headline">
                <h3><i class="icon-feather-folder-plus"></i> Job Submission Form</h3>
            </div>

            <div class="content with-padding padding-bottom-10">
                <div class="row">

                    <div class="col-xl-4">
                        <div class="submit-field">
                            <h5>Job Title</h5>
                            <input type="text" name="title" value="<?php echo e(old('name', $project->title)); ?>"
                                class="with-border">
                        </div>
                    </div>

                    <div class="col-xl-4">
                        <div class="submit-field">
                            <h5>Job Type</h5>
                            <select name="type" class="selectpicker with-border" data-size="7"
                                title="Select Job Type">

                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>" <?php if($type == old('type', $project->type)): echo 'selected'; endif; ?>><?php echo e($type); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>

                    <div class="col-xl-4">
                        <div class="submit-field">
                            <h5>Job Category</h5>
                            <select name="category_id" class="selectpicker with-border" data-size="7"
                                title="Select Category">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if($category->id == old('category_id', $project->category_id)): echo 'selected'; endif; ?>>
                                        <?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>



                    <div class="col-xl-4">
                        <div class="submit-field">
                            <h5>Budget</h5>
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="input-with-icon">
                                        <input class="with-border" type="text" name="budget"
                                            value="<?php echo e(old('name', $project->budget)); ?>">
                                        <i class="currency">USD</i>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4">
                        <div class="submit-field">
                            <h5>Tags <span>(optional)</span> <i class="help-icon" data-tippy-placement="right"
                                    title="Maximum of 10 tags"></i></h5>
                            <div class="keywords-container">
                                <div class="keyword-input-container">
                                    <input type="text" name="tags" value="<?php echo e($tags); ?>"
                                        class="keyword-input with-border"
                                        placeholder="e.g. job title, responsibilites" />
                                    <button type="button" class="keyword-input-button ripple-effect"><i
                                            class="icon-material-outline-add"></i></button>
                                </div>
                                <div class="keywords-list">
                                    <!-- keywords go here -->
                                </div>
                                <div class="clearfix"></div>
                            </div>

                        </div>
                    </div>

                    <div class="col-xl-12">
                        <div class="submit-field">
                            <h5>Job Description</h5>
                            <textarea cols="30" rows="5" class="with-border" name="description"><?php echo e($project->description); ?></textarea>
                            <div class="uploadButton margin-top-30">
                                <input class="uploadButton-input" type="file" name="attachments[]" id="upload"
                                    multiple />
                                <label class="uploadButton-button ripple-effect" for="upload">Upload Files</label>
                                <span class="uploadButton-file-name">Images or documents that might be helpful in
                                    describing your job</span>
                            </div>

 

                            <?php if(is_array($project->attachments)): ?>
                                <div>
                                    <ul>
                                        <?php $__currentLoopData = $project->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(is_string($file)): ?>
                                                <li><a
                                                        href="<?php echo e(asset('uploads/' . $file)); ?>"><?php echo e(basename($file)); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>



                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-12">
        <button type="submit" class="button ripple-effect big margin-top-30">Post a Job</button>
    </div>

</div>
<!-- Row / End -->

<!-- Footer -->
<div class="dashboard-footer-spacer"></div>
<div class="small-footer margin-top-15">
    <div class="small-footer-copyrights">
        © 2018 <strong>Hireo</strong>. All Rights Reserved.
    </div>
    <ul class="footer-social-links">
        <li>
            <a href="#" title="Facebook" data-tippy-placement="top">
                <i class="icon-brand-facebook-f"></i>
            </a>
        </li>
        <li>
            <a href="#" title="Twitter" data-tippy-placement="top">
                <i class="icon-brand-twitter"></i>
            </a>
        </li>
        <li>
            <a href="#" title="Google Plus" data-tippy-placement="top">
                <i class="icon-brand-google-plus-g"></i>
            </a>
        </li>
        <li>
            <a href="#" title="LinkedIn" data-tippy-placement="top">
                <i class="icon-brand-linkedin-in"></i>
            </a>
        </li>
    </ul>
    <div class="clearfix"></div>
</div>
<!-- Footer / End -->

</div>
</div>
<?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/client/projects/_form.blade.php ENDPATH**/ ?>