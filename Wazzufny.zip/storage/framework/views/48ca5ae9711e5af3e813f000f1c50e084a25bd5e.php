<?php if(Session::has('success')): ?>
<div class="alert alert-success">
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>
<?php if(Session::has('info')): ?>
<div class="alert alert-info">
    <?php echo e(Session::get('info')); ?>

</div>
<?php endif; ?>
<?php if(Session::has('warning')): ?>
<div class="alert alert-warning">
    <?php echo e(Session::get('warning')); ?>

</div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
<div class="alert alert-danger">
    <?php echo e(Session::get('erorr')); ?>

</div>
<?php endif; ?><?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/components/flash-message.blade.php ENDPATH**/ ?>