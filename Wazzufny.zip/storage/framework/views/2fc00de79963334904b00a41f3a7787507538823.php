 

<?php $__env->startSection('page-title'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create','App\\Models\Category')): ?>
 
Categories  <small><a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-outline-primary">create</a></small> 
 
<?php endif; ?>
 
<small><a href="<?php echo e(route('trash')); ?>" class="btn btn-sm btn-outline-danger">trash</a></small> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="container">
    

    <?php if(Session::has('success')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>slug</th>
                    <th>parent_id</th>
                    <th>created_at</th>
                    <th></th>
                </tr>
            </thead>

            <tbody>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><a href=<?php echo e(route('categories.show',$category->id)); ?> ><?php echo e($category->name); ?></a></td>
                    <td><?php echo e($category->slug); ?></td>
                    <td><?php echo e($category->parent->name); ?></td>
                    <td><?php echo e($category->created_at); ?></td>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$category)): ?>

                    <td><a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-sm btn-dark">edit</a></td>

                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$category)): ?>
                    <td>
                        <form action="<?php echo e(route('categories.destroy',$category->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
</div>

<?php echo e($categories->withQueryString()->links()); ?>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/categories/index.blade.php ENDPATH**/ ?>