

<?php $__env->startSection('page-title'); ?>
    Deleted Categories <small><a href="<?php echo e(route('categories.index')); ?>"
            class="btn btn-sm btn-outline-primary">Index</a></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">


        <?php if(Session::has('success')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>name</th>
                        <th>slug</th>
                        <th>parent_id</th>
                        <th>deleted_at</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><a href=<?php echo e(route('categories.show', $category->id)); ?>><?php echo e($category->name); ?></a></td>
                            <td><?php echo e($category->slug); ?></td>
                            <td><?php echo e($category->parent->name); ?></td>
                            <td><?php echo e($category->deleted_at); ?></td>
                            <td>
                                <form action="<?php echo e(route('restore', $category->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <button type="submit" class="btn btn-sm btn-info">Restore</button>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo e(route('forceDelete', $category->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Perma Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>
    </div>

    <?php echo e($categories->withQueryString()->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/categories/trash.blade.php ENDPATH**/ ?>