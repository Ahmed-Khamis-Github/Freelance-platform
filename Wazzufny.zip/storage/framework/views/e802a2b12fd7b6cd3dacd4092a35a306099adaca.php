
<?php $__env->startSection('page-title','Create A New Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
 

        <form action="<?php echo e(route('categories.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
           
            <?php echo $__env->make('categories._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/categories/create.blade.php ENDPATH**/ ?>