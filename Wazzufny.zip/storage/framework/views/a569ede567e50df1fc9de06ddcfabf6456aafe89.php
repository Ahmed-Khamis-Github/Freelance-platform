<select name="country" class="form-select" aria-label="Default select example">
    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($code); ?>" <?php if($code == $selected): echo 'selected'; endif; ?>> <?php echo e($name); ?> </option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select><?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/components/country-select.blade.php ENDPATH**/ ?>