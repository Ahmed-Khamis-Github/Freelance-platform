 
   <script>

    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;

    var pusher = new Pusher('7d31d658e7933427f381', {
      cluster: 'eu'
    });

    var channel = pusher.subscribe('a7a');
    channel.bind('a7a', function(data) {
      alert(JSON.stringify(data));
    });
  </script>
 <?php /**PATH C:\Users\Miso\Desktop\programming\laravel projects\laravel safadi elancer\elancer\test\Wazzufny\resources\views/welcoome.blade.php ENDPATH**/ ?>